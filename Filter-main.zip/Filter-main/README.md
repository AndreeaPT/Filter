# Filter

This is a filter which will enable GreenMobility users to quickly access car data according to their preferences. 
It includes Car type, Plate number, Fuel levels and Location :)
